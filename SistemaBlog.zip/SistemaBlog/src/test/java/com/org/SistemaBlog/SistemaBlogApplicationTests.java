package com.org.SistemaBlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
